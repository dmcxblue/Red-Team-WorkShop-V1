﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace WindowsService1
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            //What to do when it Runs
            ExecuteCommand();
        }
        protected override void OnStop()
        {
            //What to do when it Stops
        }
        public static void ExecuteCommand()
        {
            try
            {
                string command = "notepad";

                // Create a new process start info
                ProcessStartInfo processStartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",  // Use the command prompt
                    RedirectStandardInput = true,
                    CreateNoWindow = true,
                    UseShellExecute = false
                };

                // Create a new process
                using (Process process = new Process { StartInfo = processStartInfo })
                {
                    // Start the process
                    process.Start();

                    // Write the command to the standard input
                    process.StandardInput.WriteLine(command);
                    process.StandardInput.WriteLine("exit"); // Exit the command prompt

                    // Wait for the process to exit
                    process.WaitForExit();
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (log, display, etc.)
                Console.WriteLine($"Error executing command: {ex.Message}");
            }
        }
    }
}
